Description
-----------
Jacksum 1.7.0 Windows Explorer Integration 1.3.0
for Windows NT/2000/2003/XP/2008/Vista/7 Operating Systems (August 14, 2010)
Copyright (C) 2006-2010 Dipl.-Inf. (FH) Johann N. Loefflmann

The Jacksum Windows Explorer Integration program installs Jacksum's
primary functions (compute checksums, CRCs, and hashes) at the
Windows Explorer's "Send To" menu. You will also be able to run
Jacksum on the command line by typing "jacksum"

Jacksum is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

Go to http://www.jonelo.de/java/jacksum/ and get the latest version.

Go to http://www.jonelo.de/java/jacksum/index.html#windows for a
detailed description.


Requirements
------------
1) A Windows NT based Operating System (Windows NT/2000/2003/XP/2008/Vista/7)

2) A Java Runtime Environment.
   Go to http://www.java.com
   or http://java.sun.com/javase/downloads/index.jsp


Start the installer
-------------------
Just double click on "Jacksum Windows Explorer Integration.exe"


Platform Independence
---------------------
Jacksum is platform independent software. On the Jacksum homepage
at http://www.jonelo.de/java/jacksum/ you also find integration scripts
for famous file browsers on Linux- and Unix-Operating Systems such as
KDE/Konqueror, Gnome/Nautilus, ROX-Filer and Mac OS X's Finder.


Updates
-------
Keep updated by sending an email to
announce-subscribe@jacksum.dev.java.net


Bugs, Feature Requests, Support Requests
----------------------------------------
Go to http://sourceforge.net/projects/jacksum
or send an email to jonelo@jonelo.de


Acknowledgement
---------------
This installer has been created with the Nullsoft Scriptable Install
System (NSIS) 2.46. Go to http://nsis.sourceforge.net
